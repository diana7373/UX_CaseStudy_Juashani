import Button from "./components/atoms/boton";

function App() {
  return (
    <div>
      <h1>Mi app</h1>

      <Button />
    </div>
  );
}

export default App;