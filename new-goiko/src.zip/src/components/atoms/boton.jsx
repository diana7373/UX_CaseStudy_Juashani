import React from 'react';

  return (
    <button className={styles.button}>
      Comprar
    </button>
  );
}

export default Button;